<?php
  $sql = "DELETE FROM tbl_tiket WHERE KodeTiket = '$userID'";
	$simpan = mysqli_query($koneksi, $sql) or die ("tidak berhasil");
	if($simpan) { ?>
		<script>
			alert("Data Tiket berhasil dihapus !");
			document.location="admin.php?id=tiket_list";
		</script> <?php
	}
